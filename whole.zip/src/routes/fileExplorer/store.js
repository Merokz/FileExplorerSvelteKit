// store.js

import { writable } from 'svelte/store';

// Create a Svelte store to hold the contents of the currently open file
export const openFileContent = writable("");
