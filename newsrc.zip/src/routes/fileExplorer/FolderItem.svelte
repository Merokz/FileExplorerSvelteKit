<!-- FolderItem.svelte -->

<script lang="ts">
  import BaseFolderItem from "./BaseFolderItem.svelte";
  import { openFileContent, openFileHandle, isEditMode } from "./store";

  export let item: {
    kind: string;
    name: string;
    handle: any;
    isOpen: boolean;
    contents: {
      kind: string;
      name: string;
      handle: any;
      isOpen: boolean;
      contents: any[];
    }[];
  };
  export let toggleFolderOpen: (item: any) => Promise<void>;
  export let loadSubfolderContents: (item: any) => Promise<void>;

  // Function to open a file and read its contents
  async function openFile(item: any) {
    console.log("Opening file", item.name);
    if (item.kind === "file") {
      const file = await item.handle.getFile();
      const text = await file.text();
      openFileContent.set(text); // Update the store with the file's contents
      openFileHandle.set(item.fileHandle);
    }
  }
  async function saveFile() {
    const handle = $openFileHandle;
    if (!handle) {
      console.log("No file is currently open for editing");
      return;
    }

    const writable = await handle.createWritable();
    await writable.write($openFileContent);
    await writable.close();

    isEditMode.set(false);
  }
</script>

<BaseFolderItem
  {item}
  {toggleFolderOpen}
  {loadSubfolderContents}
  on:click={() => openFile(item)}
/>
