import * as universal from "../../../../src/routes/sverdle/how-to-play/+page.ts";
export { universal };
export { default as component } from "../../../../src/routes/sverdle/how-to-play/+page.svelte";