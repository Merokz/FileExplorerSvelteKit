<script lang="ts">
    import { writable } from 'svelte/store';
    import FolderItem from './FolderItem.svelte';

    interface FolderContent {
        kind: string;
        name: string;
        handle: FileSystemHandle;
        isOpen: boolean;
        contents: FolderContent[];
    }

    let folderHandle = writable<null | FileSystemDirectoryHandle>(null);
    let folderContents = writable<FolderContent[]>([]);

    async function selectFolder(handle: FileSystemDirectoryHandle | null = null, itemToUpdate: FolderContent | null = null) {
        if (!handle) {
            handle = await window.showDirectoryPicker();
        }
        folderHandle.set(handle);

        const entries = await handle.getEntries();
        const contents: FolderContent[] = [];
        for await (const entry of entries) {
            contents.push({
                kind: entry.kind,
                name: entry.name,
                handle: entry,
                isOpen: false,
                contents: [],
            });
        }

        if (itemToUpdate) {
            folderContents.update(items => items.map(item => item === itemToUpdate ? {...item, contents, isOpen: !item.isOpen} : item));
        } else {
            folderContents.set(contents);
        }
    }
</script>

<button on:click={() => selectFolder()}>Select Folder</button>

<ul>
    {#each $folderContents as item (item.name)}
        <FolderItem {item} {selectFolder} />
    {/each}
</ul>
