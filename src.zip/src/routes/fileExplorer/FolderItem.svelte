<script lang="ts">
    import BaseFolderItem from './BaseFolderItem.svelte';
    export let item: any;
    export let selectFolder: (handle?: FileSystemHandle, item?: any) => Promise<void>;
</script>

<BaseFolderItem {item} {selectFolder} />
