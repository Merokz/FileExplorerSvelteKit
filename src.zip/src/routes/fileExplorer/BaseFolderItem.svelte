<script lang="ts">
  export let item: any;
  export let selectFolder: (handle?: FileSystemHandle, item?: any) => Promise<void>;
</script>

<li on:click={() => selectFolder(item.handle, item)}>
  {item.name}
  {#if item.isOpen}
      <ul>
          {#each item.contents as childItem (childItem.name)}
              <BaseFolderItem {childItem} {selectFolder} />
          {/each}
      </ul>
  {/if}
</li>
