<!-- src/routes/fileExplorer/BaseFolderItem.svelte -->

<script lang="ts">
  import FolderItem from './FolderItem.svelte';

  export let item: {
    kind: string;
    name: string;
    handle: any;
    isOpen: boolean;
    contents: { kind: string; name: string; handle: any; isOpen: boolean; contents: any[]; }[];
  };
  export let selectFolder: (handle?: any) => Promise<void>;
</script>

<li>
  <button on:click={() => selectFolder(item.handle)} on:keydown={(e) => e.key === 'Enter' && selectFolder(item.handle)}>
    {item.name}
  </button>
  {#if item.kind === 'directory' && item.isOpen}
    <ul>
      {#each item.contents as child (child.name)}
        <FolderItem item={child} selectFolder={selectFolder} />
      {/each}
    </ul>
  {/if}
</li>

<style>
  ul {
    margin-left: 1rem;
  }
</style>
