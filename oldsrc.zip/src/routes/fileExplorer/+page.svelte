<!-- src/routes/fileExplorer/+page.svelte -->

<script lang="ts">
    import { writable } from "svelte/store";
    import FolderItem from "./FolderItem.svelte";

    // Define a type for the contents of a folder
    interface FolderContent {
        kind: string;
        name: string;
        handle: any;
        isOpen: boolean;
        contents: FolderContent[];
    }

    // Create a Svelte store to hold the folder handle
    let folderHandle = writable<null | any>(null);

    // Create a Svelte store to hold the contents of the folder
    let folderContents = writable<FolderContent[]>([]);

    // Function to open the directory picker and store the selected folder
    async function selectFolder(handle: any = null) {
        console.log("selectFolder called with handle:", handle);
        // If no handle was provided, open the directory picker
        if (!handle) {
            handle = await window.showDirectoryPicker();
        }
        // Add this check
        if (!handle) {
            console.log("No handle provided or obtained, exiting selectFolder");
            return;
        }
        folderHandle.set(handle);
        // Get the contents of the selected folder and store them
        const contents = [];
        for await (const entry of (handle as any).values()) {
            const childItem = {
                kind: entry.kind,
                name: entry.name,
                handle: entry,
                isOpen: false,
                contents: [],
            };
            if (childItem.kind === "directory") {
                childItem.name = `📂 ${childItem.name}`;
            } else {
                childItem.name = `📄 ${childItem.name}`;
            }
            contents.push(childItem);
        }
        console.log("New directory contents:", contents);

        // Store the contents in the Svelte store
        folderContents.set(contents);

        // Output the value of the Svelte store
        console.log("Updated folderContents:", $folderContents);
    }
</script>

<!-- Button to select a folder -->
<button id="select-folder-button" on:click={() => selectFolder()}>
    Select Folder
</button>

<!-- List of the selected folder's contents -->
<ul>
    {#each $folderContents as item (item.name)}
        <FolderItem {item} {selectFolder} />
    {/each}
</ul>
