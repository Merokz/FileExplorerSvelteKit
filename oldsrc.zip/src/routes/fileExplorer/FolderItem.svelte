<!-- src/routes/fileExplorer/FolderItem.svelte -->

<script lang="ts">
    import BaseFolderItem from './BaseFolderItem.svelte';
    export let item: {
      kind: string;
      name: string;
      handle: any;
      isOpen: boolean;
      contents: { kind: string; name: string; handle: any; isOpen: boolean; contents: any[]; }[];
    };
    export let selectFolder: (handle?: any) => Promise<void>;
  </script>
  
  <BaseFolderItem item={item} selectFolder={selectFolder} />
  